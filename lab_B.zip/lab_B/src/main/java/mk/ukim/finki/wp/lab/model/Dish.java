package mk.ukim.finki.wp.lab.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// Baranje 8
@Entity
@Table(name = "dishes") // Baranje 12
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Dish {
    // Baranje 8
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String dishId;
    private String name;
    private String cuisine;
    private int preparationTime;
    private int likes = 0;


    @ManyToOne
    @JoinColumn(name = "chef_id")
    private Chef chef;

    public Dish(String dishId, String name, String cuisine, int preparationTime) {
        this.likes = 0;
        this.dishId = dishId;
        this.name = name;
        this.cuisine = cuisine;
        this.preparationTime = preparationTime;
    }

    public int getLikes(){
        return likes;
    }

    public void setLikes(int likes){
        this.likes = likes;
    }

    public void incrementLikes(){
        this.likes++;
    }

    public Long getId() {
        return id;
    }

    public String getDishId() {
        return dishId;
    }

    public String getName() {
        return name;
    }

    public String getCuisine() {
        return cuisine;
    }

    public int getPreparationTime() {
        return preparationTime;
    }

}
