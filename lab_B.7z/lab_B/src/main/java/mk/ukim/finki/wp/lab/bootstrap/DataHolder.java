package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Chef;
import mk.ukim.finki.wp.lab.model.Dish;
import mk.ukim.finki.wp.lab.repository.ChefRepository;
import mk.ukim.finki.wp.lab.repository.DishRepository;
import org.springframework.stereotype.Component;

import java.util.ArrayList;


@Component
public class DataHolder {

    private final ChefRepository chefRepository;
    private final DishRepository dishRepository;

    public DataHolder(ChefRepository chefRepository, DishRepository dishRepository) {
        this.chefRepository = chefRepository;
        this.dishRepository = dishRepository;
    }

    @PostConstruct
    public void init(){
        if (chefRepository.count() == 0) {

            Chef chef1 = chefRepository.save(new Chef(null, "Gordon", "Ramsey", "Britanski gotvac so Michelin dzvezdi.", new ArrayList<>()));
            Chef chef2 = chefRepository.save(new Chef(null, "Jamie", "Oliver", "Britanski gotvac za zdrava i ednostavna hrana.", new ArrayList<>()));
            Chef chef3 = chefRepository.save(new Chef(null, "Marco", "Pierre White", "Prv so tri Michelin dzvezdi, mentor na Ramsay.", new ArrayList<>()));
            Chef chef4 = chefRepository.save(new Chef(null, "Wolfgang", "Puck", "Avstrisko-amerikanski pioner vo fjuzn kujna.", new ArrayList<>()));
            Chef chef5 = chefRepository.save(new Chef(null, "Massimo", "Bottura", "Italijanski gotvac so tri Michelin dzvezdi.", new ArrayList<>()));

            Dish dish1 = new Dish("D001", "Beef Wellington", "Britanska", 30, 4.5);
            dish1.setChef(chef1);
            dishRepository.save(dish1);
            
            Dish dish2 = new Dish("D002", "Risotto al Tartufo", "Italijanska", 25, 3.8);
            dish2.setChef(chef5);
            dishRepository.save(dish2);
            
            Dish dish3 = new Dish("D003", "Pad Thai", "Tajlandska", 15, 4.4);
            dishRepository.save(dish3);
            
            Dish dish4 = new Dish("D004", "Coq au Vin", "Francuska", 35, 3.4);
            dishRepository.save(dish4);
            
            Dish dish5 = new Dish("D005", "Sushi Omakase", "Japonska", 20, 4.9);
            dishRepository.save(dish5);
        }
    }

}